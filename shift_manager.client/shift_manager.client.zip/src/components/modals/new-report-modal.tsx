import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertEmergencyReportSchema } from "@shared/schema";
import type { Officer, Beat } from "@/lib/types";
import { createEmergencyReport } from "@/lib/api";
import { invalidateReportRelated } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

const reportFormSchema = insertEmergencyReportSchema.extend({
    reportNumber: z.string().min(1, "El número de reporte es requerido"),
    type: z.enum(["emergency", "non_emergency", "traffic", "domestic", "theft", "assault"]),
    priority: z.enum(["high", "medium", "low"]),
    description: z.string().min(1, "La descripción es requerida"),
    location: z.string().min(1, "La ubicación es requerida"),
    callerName: z.string().min(1, "El nombre del denunciante es requerido"),
    callerPhone: z.string().min(1, "El número es requerido"),
    assignedOfficerId: z.string().min(1, "Debe seleccionar un oficial"),
    beatId: z.string().min(1, "Debe seleccionar un cuadrante"),
});
type ReportFormData = z.infer<typeof reportFormSchema>;

interface NewReportModalProps { isOpen: boolean; onClose: () => void; }

export function NewReportModal({ isOpen, onClose }: NewReportModalProps) {
    const { toast } = useToast();
    const queryClient = useQueryClient();

    const form = useForm<ReportFormData>({
        resolver: zodResolver(reportFormSchema),
        defaultValues: {
            reportNumber: `RPT-${Date.now().toString().slice(-6)}`,
            type: "non_emergency", priority: "medium",
            description: "", location: "", callerName: "", callerPhone: "", status: "pending",
        },
    });

    const { data: officers } = useQuery<Officer[]>({ queryKey: ["/api/officers"] });
    const { data: beats } = useQuery<Beat[]>({ queryKey: ["/api/beats"] });

    const createReportMutation = useMutation({
        mutationFn: (data: ReportFormData) => createEmergencyReport(data),
        onSuccess: () => {
            toast({ title: "Éxito", description: "Reporte creado exitosamente" });
            queryClient.invalidateQueries({ queryKey: ["/api/emergency-reports"] });
            queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
            onClose(); form.reset();
        },
        onError: (err: Error) => {
            toast({ title: "Error", description: err.message || "No se pudo crear el reporte", variant: "destructive" });
        },
    });

    const reportTypes = [
        { value: "emergency", label: "Emergencia" },
        { value: "non_emergency", label: "No Emergencia" },
        { value: "traffic", label: "Tráfico" },
        { value: "domestic", label: "Doméstico" },
        { value: "theft", label: "Robo" },
        { value: "assault", label: "Asalto" },
    ];
    const priorityLevels = [
        { value: "high", label: "Alta", color: "text-red-600" },
        { value: "medium", label: "Media", color: "text-yellow-600" },
        { value: "low", label: "Baja", color: "text-green-600" },
    ];

    const selectedBeatId = form.watch("beatId");

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto" data-testid="modal-new-report" aria-describedby="new-report-description">
                <DialogHeader>
                    <DialogTitle>Crear Nuevo Reporte de Emergencia</DialogTitle>
                    <p id="new-report-description" className="text-sm text-gray-500 hidden">Llene los detalles para crear una nueva incidencia en la base de datos.</p>
                </DialogHeader>
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(d => createReportMutation.mutate(d))} className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <FormField control={form.control} name="reportNumber" render={({ field }) => (
                                <FormItem><FormLabel>Número de Reporte</FormLabel>
                                    <FormControl><Input {...field} placeholder="RPT-123456" data-testid="input-report-number" /></FormControl>
                                    <FormMessage /></FormItem>
                            )} />
                            <FormField control={form.control} name="type" render={({ field }) => (
                                <FormItem><FormLabel>Tipo de Reporte</FormLabel>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                        <FormControl><SelectTrigger data-testid="select-type"><SelectValue placeholder="Seleccionar Tipo" /></SelectTrigger></FormControl>
                                        <SelectContent>{reportTypes.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
                                    </Select><FormMessage /></FormItem>
                            )} />
                            <FormField control={form.control} name="priority" render={({ field }) => (
                                <FormItem><FormLabel>Prioridad</FormLabel>
                                    <Select onValueChange={field.onChange} value={field.value}>
                                        <FormControl><SelectTrigger data-testid="select-priority"><SelectValue placeholder="Seleccionar Prioridad" /></SelectTrigger></FormControl>
                                        <SelectContent>{priorityLevels.map(p => <SelectItem key={p.value} value={p.value}><span className={p.color}>{p.label}</span></SelectItem>)}</SelectContent>
                                    </Select><FormMessage /></FormItem>
                            )} />
                        </div>
                        <FormField control={form.control} name="description" render={({ field }) => (
                            <FormItem><FormLabel>Descripción del Incidente</FormLabel>
                                <FormControl><Textarea {...field} rows={4} placeholder="Describa detalladamente el incidente..." data-testid="textarea-description" /></FormControl>
                                <FormMessage /></FormItem>
                        )} />
                        <FormField control={form.control} name="location" render={({ field }) => (
                            <FormItem><FormLabel>Ubicación</FormLabel>
                                <FormControl><Input {...field} placeholder="Dirección exacta o referencias" data-testid="input-location" /></FormControl>
                                <FormMessage /></FormItem>
                        )} />
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <FormField control={form.control} name="callerName" render={({ field }) => (
                                <FormItem><FormLabel>Nombre del Denunciante</FormLabel>
                                    <FormControl><Input {...field} value={field.value || ""} placeholder="Nombre completo" data-testid="input-caller-name" /></FormControl>
                                    <FormMessage /></FormItem>
                            )} />
                            <FormField control={form.control} name="callerPhone" render={({ field }) => (
                                <FormItem><FormLabel>Teléfono del Denunciante</FormLabel>
                                    <FormControl><Input {...field} value={field.value || ""} placeholder="8091234567" data-testid="input-caller-phone" /></FormControl>
                                    <FormMessage /></FormItem>
                            )} />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <FormField control={form.control} name="beatId" render={({ field }) => (
                                <FormItem><FormLabel>Cuadrante Asignado</FormLabel>
                                    <Select onValueChange={(val) => {
                                            field.onChange(val);
                                            form.setValue("assignedOfficerId", "none"); // Resetear oficial si cambia cuadrante
                                        }} value={field.value || "none"}>
                                        <FormControl><SelectTrigger data-testid="select-beat"><SelectValue placeholder="Seleccionar Cuadrante" /></SelectTrigger></FormControl>
                                        <SelectContent>
                                            <SelectItem value="none" className="hidden">Seleccionar Cuadrante</SelectItem>
                                            {beats?.map(b => <SelectItem key={b.id} value={b.id}>{b.name} — Circunscripción {b.circunscripcion}</SelectItem>)}
                                        </SelectContent>
                                    </Select><FormMessage /></FormItem>
                            )} />
                            <FormField control={form.control} name="assignedOfficerId" render={({ field }) => (
                                <FormItem><FormLabel>Oficial Asignado</FormLabel>
                                    <Select onValueChange={field.onChange} value={field.value || "none"} disabled={!selectedBeatId || selectedBeatId === "none"}>
                                        <FormControl><SelectTrigger data-testid="select-officer"><SelectValue placeholder={!selectedBeatId || selectedBeatId === "none" ? "Primero elija un cuadrante" : "Seleccionar Oficial"} /></SelectTrigger></FormControl>
                                        <SelectContent>
                                            <SelectItem value="none" className="hidden">Seleccionar Oficial</SelectItem>
                                            {officers?.filter(o => o.status === "on_duty" && o.cuadrantes?.includes(selectedBeatId)).map(o => (
                                                <SelectItem key={o.id} value={o.id}>{o.name} — {o.badge}</SelectItem>
                                            ))}
                                            {(!officers || officers.filter(o => o.status === "on_duty" && o.cuadrantes?.includes(selectedBeatId)).length === 0) && (
                                                <SelectItem value="empty" disabled>No hay oficiales activos en este cuadrante</SelectItem>
                                            )}
                                        </SelectContent>
                                    </Select><FormMessage /></FormItem>
                            )} />
                        </div>
                        <div className="flex justify-end space-x-4 pt-4 border-t border-gray-200">
                            <Button type="button" variant="outline" onClick={onClose} data-testid="button-cancel">Cancelar</Button>
                            <Button type="submit" disabled={createReportMutation.isPending}
                                className="bg-red-600 hover:bg-red-700" data-testid="button-create">
                                {createReportMutation.isPending ? "Creando..." : "Crear Reporte"}
                            </Button>
                        </div>
                    </form>
                </Form>
            </DialogContent>
        </Dialog>
    );
}
